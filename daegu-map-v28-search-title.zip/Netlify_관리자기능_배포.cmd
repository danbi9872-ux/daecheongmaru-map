@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo 대청마루 기업지도 - 관리자 기능 포함 배포
echo.
where node >nul 2>nul
if errorlevel 1 goto no_node
where npm >nul 2>nul
if errorlevel 1 goto no_node
echo [1/4] 서버 기능 준비 중...
call npm install
if errorlevel 1 goto failed
echo.
echo [2/4] Netlify 로그인. 브라우저에서 현재 사이트가 있는 계정으로 로그인하세요.
call npx --yes netlify-cli login
if errorlevel 1 goto failed
echo.
echo [3/4] 기존 사이트 연결. 새 사이트를 만들지 말고 bejewelled-pony-2dd3ce 사이트를 선택하세요.
call npx --yes netlify-cli link
if errorlevel 1 goto failed
call npx --yes netlify-cli status
if errorlevel 1 goto failed
echo.
echo 위 연결 정보가 bejewelled-pony-2dd3ce.netlify.app 인지 확인하세요.
choice /C YN /M "이 기존 사이트에 배포하시겠습니까"
if errorlevel 2 goto cancelled
echo.
echo [4/4] 공개 사이트에 배포 중...
call npx --yes netlify-cli deploy --prod --dir=public --functions=netlify/functions
if errorlevel 1 goto failed
echo.
echo 배포 완료. https://bejewelled-pony-2dd3ce.netlify.app/admin.html 을 확인하세요.
pause
exit /b 0
:no_node
echo Node.js와 npm이 필요합니다. Node.js LTS를 설치한 뒤 이 파일을 다시 실행하세요.
pause
exit /b 1
:failed
echo.
echo 작업이 중단되었습니다. 위 오류 내용을 확인한 뒤 다시 실행하세요.
pause
exit /b 1
:cancelled
echo 배포를 취소했습니다. 사이트 연결 정보를 확인해 주세요.
pause
exit /b 0
