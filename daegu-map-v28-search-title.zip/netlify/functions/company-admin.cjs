const { getStore } = require('@netlify/blobs');
const { randomUUID, createHash, timingSafeEqual } = require('node:crypto');
const STORE = 'daegu-company-content';
const out = (statusCode, value) => ({statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'},body:JSON.stringify(value)});
const auth = event => {
  const secret=process.env.MAP_ADMIN_PASSWORD;
  if(!secret || secret.length<16) return false;
  const supplied=(event.headers.authorization||event.headers.Authorization||'').replace(/^Bearer\s+/i,'');
  const a=createHash('sha256').update(supplied).digest(),b=createHash('sha256').update(secret).digest();
  return timingSafeEqual(a,b);
};
const load = async store => (await store.get('catalog',{type:'json',consistency:'strong'})) || {records:{}};
const clean = (input,id) => {
  const str=(key,max=400)=>String(input[key]??'').trim().slice(0,max);
  const office=str('office',30),name=str('name',150),region=str('region',30),address=str('address',400);
  if(!name || !address || !region || !['대구청','대구서부지청'].includes(office)) throw new Error('기업명·관할·지역·주소를 확인해 주세요.');
  const lat=input.lat===''||input.lat==null?null:Number(input.lat),lng=input.lng===''||input.lng==null?null:Number(input.lng);
  if(lat!==null && (!Number.isFinite(lat)||lat<33||lat>39)) throw new Error('위도를 확인해 주세요.');
  if(lng!==null && (!Number.isFinite(lng)||lng<124||lng>132)) throw new Error('경도를 확인해 주세요.');
  const website=str('website',300);
  if(website && !/^https?:\/\//i.test(website)) throw new Error('홈페이지는 https:// 주소로 입력해 주세요.');
  const cert=Array.isArray(input.certification)?input.certification.slice(0,12).map(x=>String(x).trim().slice(0,100)).filter(Boolean):[];
  return {id,name,office,region,address,industry:str('industry',250),industry_group:str('industry_group',80),description:str('description',3000),website,phone:str('phone',60),employees:str('employees',40),certification:cert,lat,lng,geocode_precision:lat!==null&&lng!==null?'exact':'none'};
};
exports.handler = async event => {
  const action=event.queryStringParameters?.action||'';
  if(event.httpMethod==='GET' && action==='public') {
    try { return out(200,await load(getStore(STORE))); } catch(e){console.error(e);return out(503,{error:'기업정보를 읽을 수 없습니다.'});}
  }
  if(!auth(event)) return out(process.env.MAP_ADMIN_PASSWORD?401:503,{error:process.env.MAP_ADMIN_PASSWORD?'관리자 비밀번호를 확인해 주세요.':'관리자 비밀번호 설정이 필요합니다.'});
  if(event.httpMethod==='GET' && action==='verify') return out(200,{ok:true});
  if(event.httpMethod!=='POST') return out(405,{error:'허용되지 않은 요청입니다.'});
  try {
    const store=getStore(STORE);
    if(action==='save') {
      if((event.body||'').length>16000) return out(413,{error:'입력 내용이 너무 깁니다.'});
      const input=JSON.parse(event.body||'{}');
      const id=/^(?:\d{1,6}|admin-[a-f0-9-]{36})$/.test(String(input.id||''))?String(input.id):'admin-'+randomUUID();
      const record=clean(input,id),catalog=await load(store);
      const old=catalog.records[id]||{};
      catalog.records[id]={...record,brief:old.brief||{}};
      await store.setJSON('catalog',catalog);
      return out(200,{record:catalog.records[id]});
    }
    if(action==='upload') {
      const id=String(event.queryStringParameters?.id||''),kind=event.queryStringParameters?.kind;
      if(!/^(?:\d{1,6}|admin-[a-f0-9-]{36})$/.test(id)||!['png','pdf'].includes(kind))return out(400,{error:'기업 또는 파일 형식을 확인해 주세요.'});
      const catalog=await load(store),record=catalog.records[id];
      if(!record)return out(404,{error:'기업정보를 먼저 저장해 주세요.'});
      const bytes=Buffer.from(event.body||'',event.isBase64Encoded?'base64':'binary');
      if(!bytes.length||bytes.length>3_500_000)return out(413,{error:'파일은 3.5MB 이하로 올려 주세요.'});
      if(kind==='png' && !bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')))return out(400,{error:'PNG 파일을 선택해 주세요.'});
      if(kind==='pdf' && bytes.subarray(0,5).toString()!=='%PDF-')return out(400,{error:'PDF 파일을 선택해 주세요.'});
      const key=`brief/${id}/${randomUUID()}.${kind}`;
      await store.set(key,bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
      record.brief={...record.brief,[kind]:`/.netlify/functions/company-brief?id=${encodeURIComponent(id)}&kind=${kind}&v=${encodeURIComponent(key.split('/')[2])}`};
      await store.setJSON('catalog',catalog);
      return out(200,{record});
    }
    return out(400,{error:'알 수 없는 작업입니다.'});
  } catch(e) {console.error(e);return out(400,{error:e.message==='Unexpected end of JSON input'?'입력값을 확인해 주세요.':e.message||'저장할 수 없습니다.'});}
};
