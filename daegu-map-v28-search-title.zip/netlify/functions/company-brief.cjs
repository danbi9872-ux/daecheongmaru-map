const {getStore}=require('@netlify/blobs');
exports.handler=async event=>{
  const id=String(event.queryStringParameters?.id||''),kind=event.queryStringParameters?.kind;
  if(!/^(?:\d{1,6}|admin-[a-f0-9-]{36})$/.test(id)||!['png','pdf'].includes(kind))return {statusCode:400};
  try {
    const store=getStore('daegu-company-content');
    const catalog=(await store.get('catalog',{type:'json'}))||{records:{}};
    const url=catalog.records?.[id]?.brief?.[kind];
    if(!url)return {statusCode:404};
    const key='brief/'+id+'/'+new URL(url,'https://example.org').searchParams.get('v');
    const value=await store.get(key,{type:'arrayBuffer'});
    if(!value)return {statusCode:404};
    return {statusCode:200,isBase64Encoded:true,headers:{'Content-Type':kind==='png'?'image/png':'application/pdf','Content-Disposition':`inline; filename="company-${id}.${kind}"`,'Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'},body:Buffer.from(value).toString('base64')};
  }catch(e){console.error(e);return {statusCode:503};}
};
